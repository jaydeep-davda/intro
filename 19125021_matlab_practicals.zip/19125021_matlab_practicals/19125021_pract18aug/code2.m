string = 'jaydeep davda is a web developer';
regexp(string, 'c[aeiou]+t')
