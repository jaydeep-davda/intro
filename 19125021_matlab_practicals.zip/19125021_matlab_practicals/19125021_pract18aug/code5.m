string = 'two faces of a nuv';
[s,f,t] = regexp(string, 's(\w*)s')
