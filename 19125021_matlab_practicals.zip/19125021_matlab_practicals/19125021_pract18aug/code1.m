demo = "jaydeep davda is a student and is doing BTech IT"
stringsplit(demo)
