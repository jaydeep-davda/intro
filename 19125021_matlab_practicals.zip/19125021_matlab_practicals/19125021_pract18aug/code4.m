string = 'jaydeep davda is an IT student.';
[s,f] = regexp(str, '\w*x\w*')
