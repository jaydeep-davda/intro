string = {'jaydeep' 'sri lanka and india' 'MATLAB'};
s = regexp(str, {'[A-Z]' '\s'});
