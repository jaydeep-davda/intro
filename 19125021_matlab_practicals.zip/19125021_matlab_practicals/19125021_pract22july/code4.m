sub1=input("Mark of Subject 1:");
sub2=input("Mark of Subject 2:");
sub3=input("Mark of Subject 3:");

total = sub1+sub2+sub3;
percentage = (total/300)*100;

disp(['Total Marks:', num2str(total), '\nTotal Percentage:',num2str(percentage)]);