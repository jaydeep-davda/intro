p = input("Value of Principle:");
r = input("Value of Rate:");
t =3;
disp(['Compund Interest:', int2string((p*r*t)/100)])
