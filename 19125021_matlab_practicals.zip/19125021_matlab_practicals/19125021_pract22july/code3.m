l = input("Enter Length:");
b = input("Enter Breadth:");
h = input("Enter Height:");

surfaceArea = 2*(l*b+b*h+l*h);
volume = l*b*h;

disp(['Surface Area of Cuboid:', num2str(surfaceArea)]);
disp(['Volume of Cuboid:', num2str(volume)]);