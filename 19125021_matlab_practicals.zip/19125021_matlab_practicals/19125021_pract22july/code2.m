radius = input("Enter Raduis of Circle:");
pi = 3.14;
area = pi*radius*radius;
circumference = 2*pi*radius;

disp(['Area:', num2str(area)]);
disp(['Circumference:', num2str(circumference)]);
