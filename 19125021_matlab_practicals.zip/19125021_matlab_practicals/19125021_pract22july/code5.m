basicSalary = input('Basic Salary of Employee:');

DA = 0.7*basicSalary;
HRA = 0.15*basicSalary;
PF = 0.08*basicSalary;
IT = 0.12*basicSalary;
MA = 1000;

netSalary = basicSalary + DA + HRA + MA - PF - IT;
disp(['Net Salary of Employee:', num2str(netSalary)]);