s=input('Insert a word: ', 's');
i=1;
w=0;
l=length(s);
for i=i:l
if s(i)=='a' || s(i)=='e' || s(i)=='i' || s(i)=='o' || s(i)=='u', w=w+1;
end
end