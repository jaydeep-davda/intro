h = ["0" "0"; "1" "1"; "6" "9"; "8" "8"; "9" "6"];
num = 11;
i = 1;
j = length(num);
c = 1;
while i<=j
  [tf, index] = ismember(h, [num(i) num(j)] , "rows");
  if any(tf)
   
    c = 2;
  else 
    c = 0;
  end
  i = i+1;
  j = j-1;
end
if c == 2
  disp(["The number is a"])
else  
  disp(["The number is not a"])
end