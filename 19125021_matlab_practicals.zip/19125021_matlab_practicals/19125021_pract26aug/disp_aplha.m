s=input('Insert a word: ', 's');
l=length(s);

if any(isletter(s))
  disp(s)
end