file = importdata('marks.csv');
i = 2;
while i  length(file.textdata)
        disp([file.textdata{i,1}]);
    for j = 3:7
        disp([file.colheaders{1,j},":" num2str(file.data(i-1,j)),"\n"])
    end
    total = sum(file.data(i-1,3:end));
    pert = (total/500)*100;
    disp(["Total :",num2str(total), " Percentage: ",num2str(pert),"%"])
    i = i + 1;
end