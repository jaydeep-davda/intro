string = input('What is your string: ', 's');
if string == fliplr(string);
  disp (['The string, ' string ', is a palindrome.'])
else
  disp (['The string, ' string ', is not a palindrome.'])
end