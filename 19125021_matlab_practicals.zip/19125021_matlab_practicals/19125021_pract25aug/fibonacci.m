function [c] = fibo (a, b, n)
n = input('n:');
a =  n - 2;
b = n - 1;
c = a + b;
disp (c)
end