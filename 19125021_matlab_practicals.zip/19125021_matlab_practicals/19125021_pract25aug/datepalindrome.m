function x = datep(string)
    if str == fliplr(string)
      disp (['The String is palindrom'])
    else
      disp (['The String is not a palindrom'])
    end
end
