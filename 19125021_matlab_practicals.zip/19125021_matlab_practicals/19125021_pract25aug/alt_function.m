function f = alternate(string)
