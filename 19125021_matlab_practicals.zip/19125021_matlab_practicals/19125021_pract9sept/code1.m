function distance = program(input)

end
