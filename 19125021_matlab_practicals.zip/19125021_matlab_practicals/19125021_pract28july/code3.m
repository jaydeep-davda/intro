inputString = input("Enter a string:", "s");

disp(['Number of Charactes:', num2str(length(strrep(inputString, " ",'')))]);