inputString = char(input('Enter a String:','s'));
if isstrprop(inputString(1), "upper")
    disp(['The First Letter is capital']);
else
    disp(['The First Letter is not capital!']);
end