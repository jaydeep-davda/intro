name = "jaydeep davda";
splitted = stringsplit(name);
splitted(2)
