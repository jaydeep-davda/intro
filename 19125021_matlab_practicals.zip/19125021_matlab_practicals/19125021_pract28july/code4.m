inputString = input("Enter a String:", "s");
inputChar = input("Enter a Character:", "s");
disp(['Total occurences:', num2str(length(strfind(inputString, inputChar)))])