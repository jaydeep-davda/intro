inputString = input('Enter a String:','s');
if any(isstrprop(inputString, "upper"))
    disp(['There are capital letters']);
else
    disp(['No capital letter']);
end