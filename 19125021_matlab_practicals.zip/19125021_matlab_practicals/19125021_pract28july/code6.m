a="jaydeep davda";
a = stringsplit(inputString, " ");
if(all(isletter(a)))
    disp(['String is accepted:', num2str(length(a))]);
else
    disp(['String is rejected:']);
end
