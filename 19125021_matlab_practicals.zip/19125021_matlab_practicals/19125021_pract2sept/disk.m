function x = disc(n,fr,tr,aux)
   if n == 0
        disk([" "])
    else
        disk(n-1,fr,aux,tr)
        disk["Moved Disk ", num2str(n), " From Rod ", fr, " To Rod ", tr])
        disk(n-1,aux,tr,fr)
    end
end
