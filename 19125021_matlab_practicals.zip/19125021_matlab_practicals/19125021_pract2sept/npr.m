function x = npr(n,r)
    nume = FactCalc(n);
    sub = n-r;
    deno = FactCalc(sub);
    x = nume/deno;
end