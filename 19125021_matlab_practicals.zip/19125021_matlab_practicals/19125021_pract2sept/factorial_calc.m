n = uint64([5 10 15 20]);
f = factorial(n)