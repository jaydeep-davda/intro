cmap1=colormap(hot(15));
cmap2=colormap(winter(15));