file = importdata('image.csv');
i = 2;
disp("Salary Slip");
while i ~= length(file.rowheaders(:,1)) + 1
    disp("---------------------------------------------------------------------------------------");   
    disp(["Name: ",file.rowheaders{i,1}]);
    % for j = 1:16
    disp(["CTC:", num2str(file.data(i,1))]);
    disp(["Basic :",num2str(file.data(i,2))]);
    disp(["Da:",num2str(file.data(i,3))]);
    disp(["BRA:",num2str(file.data(i,4))]);
    disp(["Cane:",num2str(file.data(i,5))]);
    disp(["Medical:",num2str(file.data(i,6))]);
    disp(["Special:",num2str(file.data(i,7))]);
    disp(["Bans:",num2str(file.data(i,8))]);
    disp(["TA:",num2str(file.data(i,9))]);
    disp(["Total:",num2str(file.data(i,10))]);
    disp(["Coelnlatio:", num2str(file.data(i,11))])	
    disp(["Professio:", num2str(file.data(i,12))])	
    disp(["IDS:", num2str(file.data(i,13))])	
    disp(["Salary A:", num2str(file.data(i,14))])	
    disp(["TOTAL:", num2str(file.data(i,15))])
    disp(["Net Pay:", num2str(file.data(i,16))])
% end
disp("---------------------------------------------------------------------------------------");
    i = i+1;
end