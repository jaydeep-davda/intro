currentTime = datestring(now, "HH:MM:SS.FFFF")
s =  stringsplit(currentTime, ":");
s{1:end};
b = str2num(s{1,3}) + 5;
final = strcat(s{1},":",s{2},":",num2string(b))
