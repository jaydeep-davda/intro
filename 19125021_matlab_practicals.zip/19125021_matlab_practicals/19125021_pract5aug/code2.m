y = input("Enter a year:")
c = 0;
if mod(y,400) == 0
    c = 1;
end
if mod(y,100) == 0
    c = 0;
end
if mod(y,4) == 0
    c = 1;
else
    c= 0;
end

if c
    disp(["Given year is leap year"]);
else
    disp(["Given year  is not a leap year"]);

end