datestring(now, "FFF")
