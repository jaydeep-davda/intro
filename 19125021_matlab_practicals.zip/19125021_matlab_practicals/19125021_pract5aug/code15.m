date = eomday(2022,12);
diff = weekday("12/31/2022") - 3
datestr("12/31/2022" - diff)
