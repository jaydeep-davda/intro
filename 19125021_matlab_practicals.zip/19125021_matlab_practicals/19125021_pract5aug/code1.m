% Write a MATLAB script to display the various Date Time formats –
% a) Current date and time

t = datestring(now)

% b) Current year
y = datestring(now, "yyyy")

% c) Month of year

m = datestring(now, "mmm")

% d) Week number of the year

m = datestring(now, "weekday")

% e) Weekday of the week

weekday(now-1)

% f) Day of year
% g) Day of the month

% h) Day of week
