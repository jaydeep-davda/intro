for i = 0:4
    datestring(now+i)
end
