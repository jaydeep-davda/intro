d = datevector('09/25/2022');
v = datenumber(d);
day = v - datenumber(d(1), 1,0)
