datestring(now-1)
datestring(now)
datestring(now+1)
