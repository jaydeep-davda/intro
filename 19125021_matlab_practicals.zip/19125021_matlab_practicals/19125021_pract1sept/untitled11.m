n = 3
fib = zeros(n,n);
fib(1) = input('First element=\n');
fib(2) = input('Second element=\n');
for k=3:n
  fib(k) = fib(k-1) + fib(k-2);
end
fib