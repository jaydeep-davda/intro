for i = 1:10
  f = fib(i)
end
