function f = fib(n)
    if (n==1)
        f= 1;
    elseif (n == 2)
        f = 2;
    else
        f = fib(n-1) + fib(n-2);
    end
